﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace library_system
{
    public partial class AddLibraryData : Form
    {
        string newType;
        Book book;

        // Checks the string newType to see if a new member or book is being added
        // else a books stock level is updated
        private void AddLibraryData_Load(object sender, EventArgs e)
        {
            if (newType == "member")
            {
                lblTitle.Text = "Add a New Member";
                lblFirst.Text = "Enter Member Code: ";
                lblSecond.Text = "Enter Member Name: ";
                txtThird.Visible = false;
                txtFourth.Visible = false;
                txtFifth.Visible = false;
                txtSixth.Visible = false;

            }
            else if (newType == "book")
            {
                lblTitle.Text = "Add a New Book";
                lblFirst.Text = "Enter Book Code: ";
                lblSecond.Text = "Enter Book Title: ";
                lblThird.Text = "Enter Author Name: ";
                lblFourth.Text = "Enter Publisher Name: ";
                lblFifth.Text = "Borrow Limit (Days): ";
                lblSixth.Text = "Stock: ";
            }
            else
            {
                lblTitle.Text = "Change Stock Level";
                lblFirst.Text = "Currently Borrowed: ";
                txtFirst.Text = book.QuantityBorrowed.ToString();
                txtFirst.ReadOnly = true;
                lblSecond.Text = "Current Stock: ";
                txtSecond.Text = book.Quantity.ToString();
                txtSecond.ReadOnly = true;
                lblThird.Text = "Change Stock to: ";
                txtFourth.Visible = false;
                txtFifth.Visible = false;
                txtSixth.Visible = false;
            }
        }

        /// <summary>
        /// Two constructors one for adding items and one for updating an item
        /// </summary>
        public AddLibraryData(string nType)
        {
            InitializeComponent();
            newType = nType;
        }

        public AddLibraryData(Book b)
        {
            InitializeComponent();
            newType = "";
            book = b;
        }
 

        /// <summary>
        /// Calls appropriate method to get the input data 
        /// </summary>
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (newType == "member")
            {
                GetMemberData();
            }
            else if (newType == "book")
            {
                GetBookData();
            }
            else 
            {
                AlterBookStock(book);
            }
        }

        /// <summary>
        /// Gets data from visual controls and instantiates a new Member object
        /// </summary>
        /// <returns>A Member object</returns>
        public Member GetMemberData()
        {
            Member newMember = new Member(txtFirst.Text, txtSecond.Text);
            return newMember;
        }

        /// <summary>
        /// Gets data from visual controls and instantiates a new Book object
        /// </summary>
        /// <returns>A Book object</returns>
        public Book GetBookData()
        {
           
           Book newBook = new Book(txtFirst.Text, txtSecond.Text, txtThird.Text, txtFourth.Text, Convert.ToInt32(txtFifth.Text), Convert.ToInt32(txtSixth.Text));
           return newBook;
        }

        /// <summary>
        /// Checks the user input is above 0 or the current borrowed then changes the stock level
        /// in the event of bad user input an exception is thrown to make the program more robust
        /// </summary>

        public void AlterBookStock(Book book) 
        {
            try
            {
                int x = Convert.ToInt32(txtThird.Text);
                book.ChangeStock(x, book);
            }

            catch(StockValue sv)
            {
                MessageBox.Show(sv.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
             
    }
}

