﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    [Serializable]
    public class MemberCalculationsReport : IDisplay
    {
        /// <summary>
        /// A class containing some important library data on the amount of books in the library and whether they are in the library
        /// </summary>
        private int totalMembers;
        private int totalMoneyOwed;
        private double averageMoneyOwed;

        public int TotalMembers
        {
            get
            {
                return totalMembers;
            }

            set
            {
                totalMembers = value;
            }
        }

        public int TotalMoneyOwed
        {
            get
            {
                return totalMoneyOwed;
            }

            set
            {
                totalMoneyOwed = value;
            }
        }

        public double AverageMoneyOwed
        {
            get
            {
                return averageMoneyOwed;
            }

            set
            {
                averageMoneyOwed = value;
            }
        }

        public string Display()
        {
            string msg;
            string CR = Environment.NewLine;

            msg = "MONTHLY BOOKS REPORT" + CR;
            msg += "------------" + CR;

            msg += "Total members in library: " + TotalMembers.ToString() + CR;
            msg += "Amount of money owed: " + TotalMoneyOwed.ToString("C") + CR;
            msg += "Average Money owed: " + AverageMoneyOwed.ToString("C") + CR;

            return msg;
        }

    }
}
