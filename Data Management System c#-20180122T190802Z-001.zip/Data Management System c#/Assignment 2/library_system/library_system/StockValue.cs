﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    class StockValue : Exception
    {
        /// <summary>
        /// This exception is thrown in the event the stock level is changed to an invalid number
        /// </summary>
        private static string msg = " The stock value entered must be above 0 and the currently borrowed number.";

        public StockValue(int invalidStock)
            : base ("Error: " + msg)
        {

        }
    }
}
