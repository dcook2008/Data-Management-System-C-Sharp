﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    [Serializable]
    public class Book : IDisplay
    {
        //auto-implemented properties
        public string BookCode { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }
        public int BorrowLimit { get; set; }
        public int Quantity { get; set; }
        public int QuantityBorrowed { get; set; }
        public int BorrowCount {get; set; }

        public Dictionary<string, Book> BorrowedBy{ get; set; }

        // Constructor
        public Book(string bCode, string bTitle, string bAuthor, string bPublisher, int bBorrowLimit, int bQuantity)
        {
            if (bQuantity <= 0 || bBorrowLimit <= 0)
            {
                bBorrowLimit = 30;
                bQuantity = 6;

                BookCode = bCode;
                Title = bTitle;
                Author = bAuthor;
                Publisher = bPublisher;
                BorrowLimit = bBorrowLimit;
                Quantity = bQuantity;
                BorrowCount = 0;
                QuantityBorrowed = 0;

                BorrowedBy = new Dictionary<string, Book>();
            }
            else
            {
                BookCode = bCode;
                Title = bTitle;
                Author = bAuthor;
                Publisher = bPublisher;
                BorrowLimit = bBorrowLimit;
                Quantity = bQuantity;
                BorrowCount = 0;
                QuantityBorrowed = 0;

                BorrowedBy = new Dictionary<string, Book>();
            }
        }


        /// <summary>
        /// The addBorrow and removeBorrow methods used to alter book and member variables and collections in order to register the borrow or return and other
        /// information that is required as an implication of the borrow or return
        /// </summary>
        public void addBorrow(string member, Book book)
        {
            book.QuantityBorrowed += 1;
            book.BorrowCount += 1;
            BorrowedBy.Add(member, book);
        }

        public void removeBorrow(string memberCode, Book book)
        {
            book.QuantityBorrowed -= 1;
            book.BorrowCount -= 1;
            BorrowedBy.Remove(memberCode);
        }

        public void ChangeStock(int newStock, Book book)
        {
            if(newStock <= 0 || newStock < book.BorrowCount)
            {
                StockValue svException = new StockValue(newStock);
                throw(svException);
            }
            else
            {
                book.Quantity = newStock;
            }
        }

        public override string ToString()
        {
            return String.Format("{0}  {1}", BookCode, Author);
        }

        // Return a formatted string containing all data elements of a Book
        public string Display()
        {
            string msg;
            string CR = Environment.NewLine;

            msg = String.Format("\nBook Dets {0}", CR);
            msg += String.Format("   Code: {0} {1}", BookCode, CR);
            msg += String.Format("   Title: {0} {1}", Title, CR);
            msg += String.Format("   Author: {0} {1}", Author, CR);
            msg += String.Format("   Published by: {0} {1}", Publisher, CR);
            msg += String.Format("   Borrow Duration: {0} days {1}", BorrowLimit, CR);
            msg += String.Format("   Stock: {0} {1}", Quantity, CR);
            msg += String.Format("   Currently Borrow: {0} {1}", QuantityBorrowed, CR);


            //display all books that have been borrowed
            msg += DisplayBorrowed();
            msg += String.Format("------------------------------ ");
            return msg;
        }

        /// <summary>
        /// Runs through a dictionary to retrive information on what book has been borrowed and whom it has been borrowed by
        /// </summary>
        /// <returns>A formatted string</returns>
        public string DisplayBorrowed()
        {
            string msg;
            string CR = Environment.NewLine;

            msg = String.Format("{0}Borrowed Books = {1} {2}", CR, BorrowedBy.Count, CR);
            foreach (KeyValuePair<string, Book> kv in BorrowedBy)
            {
                Book b = kv.Value;
                msg += String.Format(" {0}   {1}  {2}", b.BookCode, b.Title, CR);
            }

            return msg;
        }


    }
}
