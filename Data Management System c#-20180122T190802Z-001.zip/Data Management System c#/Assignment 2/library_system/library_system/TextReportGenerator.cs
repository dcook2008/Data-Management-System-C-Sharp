﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;

namespace library_system
{
    public class TextReportGenerator
    {
        
        /// <summary>
        ///  This method takes an object of type IDisplay and uses the Display() method to write its details to
        ///  a text file using the name given in the filepath as the name of the file
        /// </summary>

        public void GenerateReport(IDisplay obj, string filePath)
        {
            FileStream outFile;
            StreamWriter writer;

            outFile = new FileStream(filePath, FileMode.Create, FileAccess.Write);
            writer = new StreamWriter(outFile);

            writer.WriteLine(obj.Display());

            writer.Close();
            outFile.Close();
        }
    }
}
