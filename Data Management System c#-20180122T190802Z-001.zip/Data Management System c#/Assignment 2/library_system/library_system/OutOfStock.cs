﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    class OutOfStock : Exception
    {
        /// <summary>
        /// This exception is thrown in the event a member attempts to borrow a book that is not in stock currently
        /// </summary>
        private static string msg = " All copies of this book have been borrowed by other library members.";

        public OutOfStock(string bookcode)
            : base ("Error: " + bookcode + msg)
        {

        }
    }
}
