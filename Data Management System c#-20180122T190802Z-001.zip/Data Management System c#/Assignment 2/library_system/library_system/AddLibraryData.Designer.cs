﻿namespace library_system
{
    partial class AddLibraryData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtFourth = new System.Windows.Forms.TextBox();
            this.lblFourth = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btbCancel = new System.Windows.Forms.Button();
            this.txtThird = new System.Windows.Forms.TextBox();
            this.lblThird = new System.Windows.Forms.Label();
            this.txtSecond = new System.Windows.Forms.TextBox();
            this.lblSecond = new System.Windows.Forms.Label();
            this.txtFirst = new System.Windows.Forms.TextBox();
            this.lblFirst = new System.Windows.Forms.Label();
            this.txtFifth = new System.Windows.Forms.TextBox();
            this.txtSixth = new System.Windows.Forms.TextBox();
            this.lblFifth = new System.Windows.Forms.Label();
            this.lblSixth = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(98, 41);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(0, 16);
            this.lblTitle.TabIndex = 21;
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtFourth
            // 
            this.txtFourth.Location = new System.Drawing.Point(193, 199);
            this.txtFourth.Name = "txtFourth";
            this.txtFourth.Size = new System.Drawing.Size(116, 20);
            this.txtFourth.TabIndex = 20;
            // 
            // lblFourth
            // 
            this.lblFourth.Location = new System.Drawing.Point(40, 202);
            this.lblFourth.Name = "lblFourth";
            this.lblFourth.Size = new System.Drawing.Size(147, 17);
            this.lblFourth.TabIndex = 19;
            this.lblFourth.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(75, 336);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 18;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btbCancel
            // 
            this.btbCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btbCancel.Location = new System.Drawing.Point(208, 336);
            this.btbCancel.Name = "btbCancel";
            this.btbCancel.Size = new System.Drawing.Size(75, 23);
            this.btbCancel.TabIndex = 17;
            this.btbCancel.Text = "Cancel";
            this.btbCancel.UseVisualStyleBackColor = true;
            // 
            // txtThird
            // 
            this.txtThird.Location = new System.Drawing.Point(193, 158);
            this.txtThird.Name = "txtThird";
            this.txtThird.Size = new System.Drawing.Size(116, 20);
            this.txtThird.TabIndex = 16;
            // 
            // lblThird
            // 
            this.lblThird.Location = new System.Drawing.Point(40, 162);
            this.lblThird.Name = "lblThird";
            this.lblThird.Size = new System.Drawing.Size(147, 17);
            this.lblThird.TabIndex = 15;
            this.lblThird.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSecond
            // 
            this.txtSecond.Location = new System.Drawing.Point(193, 119);
            this.txtSecond.Name = "txtSecond";
            this.txtSecond.Size = new System.Drawing.Size(116, 20);
            this.txtSecond.TabIndex = 14;
            // 
            // lblSecond
            // 
            this.lblSecond.Location = new System.Drawing.Point(40, 119);
            this.lblSecond.Name = "lblSecond";
            this.lblSecond.Size = new System.Drawing.Size(147, 17);
            this.lblSecond.TabIndex = 13;
            this.lblSecond.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtFirst
            // 
            this.txtFirst.Location = new System.Drawing.Point(193, 75);
            this.txtFirst.Name = "txtFirst";
            this.txtFirst.Size = new System.Drawing.Size(116, 20);
            this.txtFirst.TabIndex = 12;
            // 
            // lblFirst
            // 
            this.lblFirst.Location = new System.Drawing.Point(40, 77);
            this.lblFirst.Name = "lblFirst";
            this.lblFirst.Size = new System.Drawing.Size(147, 17);
            this.lblFirst.TabIndex = 11;
            this.lblFirst.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtFifth
            // 
            this.txtFifth.Location = new System.Drawing.Point(193, 240);
            this.txtFifth.Name = "txtFifth";
            this.txtFifth.Size = new System.Drawing.Size(116, 20);
            this.txtFifth.TabIndex = 22;
            // 
            // txtSixth
            // 
            this.txtSixth.Location = new System.Drawing.Point(193, 284);
            this.txtSixth.Name = "txtSixth";
            this.txtSixth.Size = new System.Drawing.Size(116, 20);
            this.txtSixth.TabIndex = 23;
            // 
            // lblFifth
            // 
            this.lblFifth.Location = new System.Drawing.Point(40, 241);
            this.lblFifth.Name = "lblFifth";
            this.lblFifth.Size = new System.Drawing.Size(147, 17);
            this.lblFifth.TabIndex = 24;
            this.lblFifth.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSixth
            // 
            this.lblSixth.Location = new System.Drawing.Point(40, 284);
            this.lblSixth.Name = "lblSixth";
            this.lblSixth.Size = new System.Drawing.Size(147, 17);
            this.lblSixth.TabIndex = 25;
            this.lblSixth.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AddLibraryData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 406);
            this.Controls.Add(this.lblSixth);
            this.Controls.Add(this.lblFifth);
            this.Controls.Add(this.txtSixth);
            this.Controls.Add(this.txtFifth);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtFourth);
            this.Controls.Add(this.lblFourth);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btbCancel);
            this.Controls.Add(this.txtThird);
            this.Controls.Add(this.lblThird);
            this.Controls.Add(this.txtSecond);
            this.Controls.Add(this.lblSecond);
            this.Controls.Add(this.txtFirst);
            this.Controls.Add(this.lblFirst);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "AddLibraryData";
            this.Text = "AddLibraryData";
            this.Load += new System.EventHandler(this.AddLibraryData_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtFourth;
        private System.Windows.Forms.Label lblFourth;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btbCancel;
        private System.Windows.Forms.TextBox txtThird;
        private System.Windows.Forms.Label lblThird;
        private System.Windows.Forms.TextBox txtSecond;
        private System.Windows.Forms.Label lblSecond;
        private System.Windows.Forms.TextBox txtFirst;
        private System.Windows.Forms.Label lblFirst;
        private System.Windows.Forms.TextBox txtFifth;
        private System.Windows.Forms.TextBox txtSixth;
        private System.Windows.Forms.Label lblFifth;
        private System.Windows.Forms.Label lblSixth;
    }
}