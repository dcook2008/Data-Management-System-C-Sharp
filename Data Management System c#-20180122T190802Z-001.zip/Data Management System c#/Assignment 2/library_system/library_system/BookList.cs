﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    [Serializable]
    public class BookList : IDisplay
    {
        // List of Book objects
        public List<Book> Books;


        public BookList()
        {
            Books = new List<Book>();
        }

        /// <summary>
        /// Add new Book to the list checking the bookCode has not already been used if the bookCode is found 
        /// before the loop has finished the break statement ends the loop 
        /// </summary> 
        public bool AddBook(Book book)
        {
            bool success = true;
            
            foreach (Book b in Books)
            {
                if (b.BookCode == book.BookCode)
                {
                    success = false;
                    break;
                }
            }
            
            if (success)
            {
                Books.Add(book);
            }
            return success;
        }

        // Find a book by using the bookCode
        public Book FindItem(string bBookCode)
        {
            Book book = null;
            foreach (Book b in Books)
            {
                if (b.BookCode == bBookCode)
                {
                    book = b;
                }
            }
            return book;
        }

        /// <summary>
        /// Three methods used to gather numeric data on the library system
        /// </summary>
        public int TotalBooks()
        {
            return Books.Count;
        }

        public int BooksLoaned()
        {
            int b = 0;
            foreach (var bookborrowed in Books)
            {
                    b += bookborrowed.BorrowCount;
            }
            return b;
        }

        public double AvgBorrowed()
        {
            int tB = TotalBooks();
            int bL = BooksLoaned();

            if (tB == 0 || bL == 0)
            {
                return 0;
            }

            return(tB/bL);
        }


        /// <returns>A list of all the books within the library system</returns>
        public string Display()
        {
            string msg;
            string CR = Environment.NewLine;

            msg = "BOOK LIST" + CR;
            msg += "------------" + CR;

            foreach (Book b in Books)
            {
                msg += String.Format("{0}  {1}{2}", b.BookCode, b.Title, CR);
            }

            msg += CR + "No. of items: " + Books.Count() + CR;
            return msg;
        }






    }
}
