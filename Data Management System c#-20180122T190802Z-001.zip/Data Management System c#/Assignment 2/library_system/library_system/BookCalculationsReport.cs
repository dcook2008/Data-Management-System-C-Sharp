﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    [Serializable]
    public class BookCalculationsReport : IDisplay
    {
        /// <summary>
        /// A class containing some important library data on the amount of books in the library and whether they are in the library
        /// </summary>
        private int booksBorrowed;
        private double avgBorrowed;
        private int totalBooks;

        public int BooksBorrowed
        {
            get
            {
                return booksBorrowed;
            }

            set
            {
                booksBorrowed = value;
            }
        }

        public double AvgBorrowed
        {
            get
            {
                return avgBorrowed;
            }

            set
            {
                avgBorrowed = value;
            }
        }

        public int TotalBooks
        {
            get
            {
                return totalBooks;
            }

            set
            {
                totalBooks = value;
            }
        }

        public string Display() 
        {
            string msg;
            string CR = Environment.NewLine;

            msg = "MONTHLY BOOKS REPORT" + CR;
            msg += "------------" + CR;

            msg += "Total books in library: " + TotalBooks.ToString() + CR;
            msg += "Books currently Borrowed: " + BooksBorrowed.ToString() + CR;
            msg += "Average borrowed: " + AvgBorrowed.ToString() + CR;

            return msg;
        }
        
    }
}
