﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    [Serializable]
    public class MemberList : IDisplay
    {
        // Generic List of Member objects
        public List<Member> Members;

        public MemberList()
        {
            Members = new List<Member>();
        }

        /// <summary>
        /// Add new Member to the list checking the member Code has not already been used if the member Code is found 
        /// before the loop has finished the break statement ends the loop 
        /// </summary> 
        public bool AddMember(Member member)
        {
            bool success = true;

            foreach (Member m in Members)
            {
                if (m.Code == member.Code)
                {
                    success = false;
                    break;
                }
            }

            if (success)
            {
                Members.Add(member);
            }
            return success;
        }

        /// <summary>
        /// Find a member by using the book code
        /// </summary>
        /// <returns>A Member</returns>
 
        public Member FindItem(string mCode)
        {
            Member member = null;
            foreach (Member m in Members)
            {
                if (m.Code == mCode)
                {
                    member = m;
                }
            }
            return member;
        }

        /// <summary>
        /// Three methods used to gather numeric data on the library system
        /// </summary>
        public int MembersAmount()
        {
            return Members.Count;
        }

        public int MembersMoney()
        {
            int money = 0;

            foreach (var member in Members)
            {
                money += member.MoneyOwed;
            }
            return money;
        }

        public double AvgMoneyOwed()
        {
            int mA = MembersAmount();
            int mM = MembersMoney();
            if (mA == 0 || mM == 0)
            {
                return 0;
            }

            return (mA / mM);
        }

        /// <returns>A list of all the members within the library system</returns>
        public string Display()
        {
            string msg;
            string CR = Environment.NewLine;

            msg = "MEMBER LIST" + CR;
            msg += "------------" + CR;

            foreach (Member m in Members)
            {
                msg += String.Format("{0}  {1}{2}", m.Code, m.Name, CR);
            }

            msg += CR + "No. of items: " + Members.Count() + CR;
            return msg;
        }

    }
}
