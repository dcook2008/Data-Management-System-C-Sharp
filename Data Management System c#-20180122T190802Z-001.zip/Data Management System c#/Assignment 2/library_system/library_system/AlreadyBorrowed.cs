﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    public class AlreadyBorrowed : Exception
    {
        /// <summary>
        /// Throws a exception when a user attempts to borrow a book they are already in possesion of
        /// </summary>
        private static string msg = " This member has already borrowed this book and has yet to return it.";

        public AlreadyBorrowed(string bookcode)
            : base ("Error: " + bookcode + msg)
        {

        }
    }
}
