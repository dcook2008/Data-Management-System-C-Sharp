﻿namespace library_system
{
    partial class FormsBasedUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBorrowReturn = new System.Windows.Forms.Label();
            this.lblDisplay = new System.Windows.Forms.Label();
            this.btnDisplayAllBooks = new System.Windows.Forms.Button();
            this.btnAddBook = new System.Windows.Forms.Button();
            this.btnAddMember = new System.Windows.Forms.Button();
            this.btnDisplayAllMembers = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnBorrow = new System.Windows.Forms.Button();
            this.lblBooks = new System.Windows.Forms.Label();
            this.lstMembers = new System.Windows.Forms.ListBox();
            this.lblMembers = new System.Windows.Forms.Label();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.lstBooks = new System.Windows.Forms.ListBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.memberToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bookToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.allMemberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allBooksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.memberReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnChangeStock = new System.Windows.Forms.Button();
            this.btnFee = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblBorrowReturn
            // 
            this.lblBorrowReturn.Location = new System.Drawing.Point(299, 321);
            this.lblBorrowReturn.Name = "lblBorrowReturn";
            this.lblBorrowReturn.Size = new System.Drawing.Size(177, 29);
            this.lblBorrowReturn.TabIndex = 40;
            this.lblBorrowReturn.Text = "To borrow or return a book, select a book and a member from each list";
            // 
            // lblDisplay
            // 
            this.lblDisplay.AutoSize = true;
            this.lblDisplay.Location = new System.Drawing.Point(629, 140);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(188, 13);
            this.lblDisplay.TabIndex = 39;
            this.lblDisplay.Text = "Individual Member or Book Information";
            // 
            // btnDisplayAllBooks
            // 
            this.btnDisplayAllBooks.Location = new System.Drawing.Point(33, 246);
            this.btnDisplayAllBooks.Name = "btnDisplayAllBooks";
            this.btnDisplayAllBooks.Size = new System.Drawing.Size(104, 43);
            this.btnDisplayAllBooks.TabIndex = 38;
            this.btnDisplayAllBooks.Text = "All Books";
            this.btnDisplayAllBooks.UseVisualStyleBackColor = true;
            this.btnDisplayAllBooks.Click += new System.EventHandler(this.btnDisplayAllBooks_Click);
            // 
            // btnAddBook
            // 
            this.btnAddBook.Location = new System.Drawing.Point(149, 246);
            this.btnAddBook.Name = "btnAddBook";
            this.btnAddBook.Size = new System.Drawing.Size(104, 43);
            this.btnAddBook.TabIndex = 37;
            this.btnAddBook.Text = "Add New Book";
            this.btnAddBook.UseVisualStyleBackColor = true;
            this.btnAddBook.Click += new System.EventHandler(this.btnAddBook_Click);
            // 
            // btnAddMember
            // 
            this.btnAddMember.Location = new System.Drawing.Point(399, 246);
            this.btnAddMember.Name = "btnAddMember";
            this.btnAddMember.Size = new System.Drawing.Size(104, 43);
            this.btnAddMember.TabIndex = 36;
            this.btnAddMember.Text = "Add New Member";
            this.btnAddMember.UseVisualStyleBackColor = true;
            this.btnAddMember.Click += new System.EventHandler(this.btnAddMember_Click);
            // 
            // btnDisplayAllMembers
            // 
            this.btnDisplayAllMembers.Location = new System.Drawing.Point(283, 246);
            this.btnDisplayAllMembers.Name = "btnDisplayAllMembers";
            this.btnDisplayAllMembers.Size = new System.Drawing.Size(104, 43);
            this.btnDisplayAllMembers.TabIndex = 35;
            this.btnDisplayAllMembers.Text = "All Members";
            this.btnDisplayAllMembers.UseVisualStyleBackColor = true;
            this.btnDisplayAllMembers.Click += new System.EventHandler(this.btnDisplayAllMembers_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(393, 375);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(104, 43);
            this.btnReturn.TabIndex = 33;
            this.btnReturn.Text = "Return Book";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnBorrow
            // 
            this.btnBorrow.Location = new System.Drawing.Point(283, 375);
            this.btnBorrow.Name = "btnBorrow";
            this.btnBorrow.Size = new System.Drawing.Size(104, 43);
            this.btnBorrow.TabIndex = 32;
            this.btnBorrow.Text = "Borrow Book";
            this.btnBorrow.UseVisualStyleBackColor = true;
            this.btnBorrow.Click += new System.EventHandler(this.btnBorrow_Click);
            // 
            // lblBooks
            // 
            this.lblBooks.AutoSize = true;
            this.lblBooks.Location = new System.Drawing.Point(118, 50);
            this.lblBooks.Name = "lblBooks";
            this.lblBooks.Size = new System.Drawing.Size(37, 13);
            this.lblBooks.TabIndex = 30;
            this.lblBooks.Text = "Books";
            // 
            // lstMembers
            // 
            this.lstMembers.FormattingEnabled = true;
            this.lstMembers.Location = new System.Drawing.Point(283, 66);
            this.lstMembers.Name = "lstMembers";
            this.lstMembers.Size = new System.Drawing.Size(220, 160);
            this.lstMembers.TabIndex = 29;
            this.lstMembers.SelectedIndexChanged += new System.EventHandler(this.lstMembers_SelectedIndexChanged);
            // 
            // lblMembers
            // 
            this.lblMembers.AutoSize = true;
            this.lblMembers.Location = new System.Drawing.Point(363, 50);
            this.lblMembers.Name = "lblMembers";
            this.lblMembers.Size = new System.Drawing.Size(50, 13);
            this.lblMembers.TabIndex = 27;
            this.lblMembers.Text = "Members";
            // 
            // txtDisplay
            // 
            this.txtDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDisplay.Location = new System.Drawing.Point(577, 157);
            this.txtDisplay.Multiline = true;
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.ReadOnly = true;
            this.txtDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDisplay.Size = new System.Drawing.Size(315, 240);
            this.txtDisplay.TabIndex = 26;
            // 
            // lstBooks
            // 
            this.lstBooks.FormattingEnabled = true;
            this.lstBooks.Location = new System.Drawing.Point(33, 66);
            this.lstBooks.Name = "lstBooks";
            this.lstBooks.Size = new System.Drawing.Size(220, 160);
            this.lstBooks.TabIndex = 25;
            this.lstBooks.SelectedIndexChanged += new System.EventHandler(this.lstBooks_SelectedIndexChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(967, 24);
            this.menuStrip1.TabIndex = 31;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.memberToolStripMenuItem1,
            this.bookToolStripMenuItem1,
            this.allMemberToolStripMenuItem,
            this.allBooksToolStripMenuItem,
            this.bookReportToolStripMenuItem,
            this.memberReportToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // memberToolStripMenuItem1
            // 
            this.memberToolStripMenuItem1.Name = "memberToolStripMenuItem1";
            this.memberToolStripMenuItem1.Size = new System.Drawing.Size(225, 22);
            this.memberToolStripMenuItem1.Text = "Member Report";
            this.memberToolStripMenuItem1.Click += new System.EventHandler(this.memberToolStripMenuItem1_Click);
            // 
            // bookToolStripMenuItem1
            // 
            this.bookToolStripMenuItem1.Name = "bookToolStripMenuItem1";
            this.bookToolStripMenuItem1.Size = new System.Drawing.Size(225, 22);
            this.bookToolStripMenuItem1.Text = "Book Report";
            this.bookToolStripMenuItem1.Click += new System.EventHandler(this.bookToolStripMenuItem1_Click);
            // 
            // allMemberToolStripMenuItem
            // 
            this.allMemberToolStripMenuItem.Name = "allMemberToolStripMenuItem";
            this.allMemberToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.allMemberToolStripMenuItem.Text = "All Member Report";
            this.allMemberToolStripMenuItem.Click += new System.EventHandler(this.allMemberToolStripMenuItem_Click);
            // 
            // allBooksToolStripMenuItem
            // 
            this.allBooksToolStripMenuItem.Name = "allBooksToolStripMenuItem";
            this.allBooksToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.allBooksToolStripMenuItem.Text = "All books Report";
            this.allBooksToolStripMenuItem.Click += new System.EventHandler(this.allBooksToolStripMenuItem_Click);
            // 
            // bookReportToolStripMenuItem
            // 
            this.bookReportToolStripMenuItem.Name = "bookReportToolStripMenuItem";
            this.bookReportToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.bookReportToolStripMenuItem.Text = "Book Calculations Report";
            this.bookReportToolStripMenuItem.Click += new System.EventHandler(this.bookReportToolStripMenuItem_Click);
            // 
            // memberReportToolStripMenuItem
            // 
            this.memberReportToolStripMenuItem.Name = "memberReportToolStripMenuItem";
            this.memberReportToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.memberReportToolStripMenuItem.Text = "Member Calculations Report";
            this.memberReportToolStripMenuItem.Click += new System.EventHandler(this.memberReportToolStripMenuItem_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(832, 468);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(104, 43);
            this.btnExit.TabIndex = 41;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnChangeStock
            // 
            this.btnChangeStock.Location = new System.Drawing.Point(42, 375);
            this.btnChangeStock.Name = "btnChangeStock";
            this.btnChangeStock.Size = new System.Drawing.Size(104, 43);
            this.btnChangeStock.TabIndex = 42;
            this.btnChangeStock.Text = "Change Stock";
            this.btnChangeStock.UseVisualStyleBackColor = true;
            this.btnChangeStock.Click += new System.EventHandler(this.btnChangeStock_Click);
            // 
            // btnFee
            // 
            this.btnFee.Location = new System.Drawing.Point(577, 403);
            this.btnFee.Name = "btnFee";
            this.btnFee.Size = new System.Drawing.Size(104, 43);
            this.btnFee.TabIndex = 44;
            this.btnFee.Text = "Pay Fee";
            this.btnFee.UseVisualStyleBackColor = true;
            this.btnFee.Click += new System.EventHandler(this.btnFee_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(56, 321);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 29);
            this.label1.TabIndex = 45;
            this.label1.Text = "To increase or decrease the stock level of a particular book select a book from t" +
    "he list";
            // 
            // FormsBasedUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Menu;
            this.ClientSize = new System.Drawing.Size(967, 532);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFee);
            this.Controls.Add(this.btnChangeStock);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblBorrowReturn);
            this.Controls.Add(this.lblDisplay);
            this.Controls.Add(this.btnDisplayAllBooks);
            this.Controls.Add(this.btnAddBook);
            this.Controls.Add(this.btnAddMember);
            this.Controls.Add(this.btnDisplayAllMembers);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnBorrow);
            this.Controls.Add(this.lblBooks);
            this.Controls.Add(this.lstMembers);
            this.Controls.Add(this.lblMembers);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.lstBooks);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormsBasedUI";
            this.Text = "Library System";
            this.Load += new System.EventHandler(this.FormsBasedUI_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBorrowReturn;
        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Button btnDisplayAllBooks;
        private System.Windows.Forms.Button btnAddBook;
        private System.Windows.Forms.Button btnAddMember;
        private System.Windows.Forms.Button btnDisplayAllMembers;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnBorrow;
        private System.Windows.Forms.Label lblBooks;
        private System.Windows.Forms.ListBox lstMembers;
        private System.Windows.Forms.Label lblMembers;
        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.ListBox lstBooks;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem memberToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bookToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem allMemberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allBooksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem memberReportToolStripMenuItem;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnChangeStock;
        private System.Windows.Forms.Button btnFee;
        private System.Windows.Forms.Label label1;
    }
}

