﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    /// <summary>
    /// An interface that contains the methods below to be used in the library system program
    /// </summary>
    interface IUserInterface
    {
        IDisplay GetItem(string m);
        void DisplayAll(IDisplay obj);
        void AddMember();
        void AddBook();

        void BorrowBook();
        void ReturnBook();

        void ChangeStock(Book book);
        void PayFee(Member member);

        void GenerateTextReport(IDisplay obj);


        void SaveLibraryData();
        void LoadLibraryData();
    }
}
