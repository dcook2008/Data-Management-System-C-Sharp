﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    [Serializable]
    public class Member : IDisplay
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public int BooksBorrowed { get; set; }
        public int MoneyOwed { get; set; }

        // Declare a List to hold references for each book a library member has borrowed
        public Dictionary<Book, Borrow> BorrowedBooks { get; set; }

        /// <summary>
        /// The constructor takes two parameters the other are automated including a 
        /// dictionary used to store information on all the members current borrows
        /// </summary>
        public Member(string code, string name)
        {
            Code = code;
            Name = name;
            BooksBorrowed = 0;
            MoneyOwed = 0;

            
            BorrowedBooks = new Dictionary<Book, Borrow>();
        }


        /// <returns>Code and name of member</returns>
        public override string ToString()
        {
            return String.Format("{0}  {1}", Code, Name);
        }

        /// <summary>
        /// The add book method is used to add a borrow to the dictionary so all user borrows can be tracked also the number of booksBorrowed is change so vital
        /// library system data can be update and maintained in order to run the system realistically
        /// </summary>
 
        public void BorrowBook(Book book, Borrow borrow)
        {
            BorrowedBooks.Add(book, borrow);
            BooksBorrowed += 1;
        }
        
        /// <summary>
        /// The return book method is used to remove a borrow from the dictionary and decrease the amount of books that have been borrowed
        /// </summary>
        public void ReturnBook(Book book)
        {
            BooksBorrowed -= 1;
            BorrowedBooks.Remove(book);
        }

        /// <summary>
        /// A simple method used to pay a members debt off in one go
        /// </summary>
        public void PayDebt()
        {
            MoneyOwed = 0;
        }


        /// <returns>Return a formatted string containing all Member data</returns>
        public string Display()
        {
            string msg;
            string CR = Environment.NewLine;

            msg =  String.Format("Code: {0} {1}", Code, CR);
            msg += String.Format("Name: {0} {1}", Name, CR);
            msg += String.Format("Books Borrowed: {0} {1}", BooksBorrowed, CR);
            msg += String.Format("Money Owed: {0} {1}", MoneyOwed.ToString("C"), CR);

            // Display all the books a member has borrowed
            msg += DisplayBorrowedBooks();
            msg += CR;


            msg += String.Format("-----------------------------------{0}", CR);
            return msg;

        }

        

        
        /// <summary>
        /// Return a string that shows all the books a user has borrowed from the library
        /// </summary>
        /// <returns>A formatted string</returns>
        public string DisplayBorrowedBooks()
        {
            string msg;
            string CR = Environment.NewLine;

            msg = String.Format("{0}Books borrowed: {1}", CR, CR);
            if (BorrowedBooks.Count == 0)
            {
                msg += String.Format("No books borrowed {0}", CR);
            }
            else
            {
                
                foreach (KeyValuePair<Book, Borrow> kv in BorrowedBooks)
                {
                    Book b = kv.Key;
                    Borrow bw = kv.Value;
                    msg += String.Format(" {0}{1}{2}{3}{4}", b.BookCode, b.Title, CR + " Days borrowed: ", bw.DaysBorrowed , CR, CR);
                }
            }
            return msg;
        }






    }
}
