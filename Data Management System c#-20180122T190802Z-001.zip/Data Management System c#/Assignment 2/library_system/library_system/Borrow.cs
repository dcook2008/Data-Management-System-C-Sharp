﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    [Serializable]
    public class Borrow : IDisplay
    {
        public int DaysBorrowed { get; set; }


        /// <summary>
        /// A set of three different constructors to be used in a particular context within the library system program
        /// </summary>
        public Borrow()
        {
            DaysBorrowed = 0;
        }

        public Borrow(Book book, Member member)
        {
            if (book.BorrowedBy.ContainsKey(member.Code)) 
            {
                AlreadyBorrowed abException = new AlreadyBorrowed(member.Code);
                throw (abException);
            }
            else if (book.QuantityBorrowed >= book.Quantity)
            {
                OutOfStock osException = new OutOfStock(book.BookCode);
                throw (osException);
            }
            else
            {
                DaysBorrowed = 0;
                book.addBorrow(member.Code, book);
                member.BorrowBook(book, this);
            }  
        }

        /// <summary>
        /// The Borrow and return methods used to register a borrow and update the objects it affects Member and Book
        /// </summary>
        public Borrow(Book book, Member member, int db)
        {
            DaysBorrowed = db;
            book.addBorrow(member.Code, book);
            member.BorrowBook(book, this);
            ChargeMember(book, member);
        }

        public void ReturnBook(Book book, Member member)
        {
            book.removeBorrow(member.Code, book);
            member.ReturnBook(book);
        }

        /// <summary>
        /// If a book has been borrowed beyond its borrow limit charge the member 
        /// </summary>
        public void ChargeMember(Book book, Member member)
        {
            if (DaysBorrowed > book.BorrowLimit)
            {
                member.MoneyOwed = 2;
            }
        }

        /// <summary>
        /// Shows how long a book has been with a member
        /// </summary>
        /// <returns>A formatted string</returns>
        public string Display()
        {
            string msg;
            string CR = Environment.NewLine;

            msg = String.Format("Days borrowed: {0}{1}{2}", DaysBorrowed, CR, CR);
            
            return msg;
        }

    }
}
