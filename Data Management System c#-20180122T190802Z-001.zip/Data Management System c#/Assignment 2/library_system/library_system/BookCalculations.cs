﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    [Serializable]
    public class BookCalculations
    {
        /// <summary>
        /// A class used to get the data for the BookCalculationsReport class allowing the attributes within it to be controlled elsewhere
        /// </summary>
        private readonly BookCalculationsReport bookCalculationsReport;
        private readonly BookList bookList;

        public BookCalculations(BookCalculationsReport monthlyBookReport, BookList bookList)
        {
            this.bookCalculationsReport = monthlyBookReport;
            this.bookList = bookList;
        }

        public void DoCalculations()
        {
            bookCalculationsReport.BooksBorrowed = bookList.BooksLoaned();
            bookCalculationsReport.AvgBorrowed = bookList.AvgBorrowed();
            bookCalculationsReport.TotalBooks = bookList.TotalBooks();

            
        }
    }
}
