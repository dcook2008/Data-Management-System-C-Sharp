﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace library_system
{
    public class SerializeFileHandler
    {
        /// <summary>
        /// Write the Library object containing all the data to a binary file using serialisation
        /// </summary>
        public void SaveLibraryFile(Library library, string filePath)
        {
            FileStream outFile;
            BinaryFormatter bFormatter = new BinaryFormatter();

            // Open file for output
            outFile = new FileStream(filePath, FileMode.Create, FileAccess.Write);

            // Output object to file via serialization
            bFormatter.Serialize(outFile, library);

            // Close file
            outFile.Close();
        }

        /// <summary>
        /// Read the binary file that contains all the application data into the application by the 
        /// serialisation of the Library file that converts it into a object and returns it
        /// </summary>
        public Library LoadLibraryFile(String filePath)
        {
            FileStream inFile;
            BinaryFormatter bFormatter = new BinaryFormatter();
            Library library = new Library();

            // Open file for input
            inFile = new FileStream(filePath, FileMode.Open, FileAccess.Read);

            // Obtain objects from file via serialization
            library = (Library)bFormatter.Deserialize(inFile);

            inFile.Close();
            return library;
        }
    }
}
