﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    public class LibraryData
    {
        /// <summary>
        /// A group of four strings that will be used as the file names of reports that can be generate when the library system program is in use
        /// </summary>
       
        public const string MEMBERS = "AllMember";
        public const string BOOKS = "AllBooks";
        public const string BOOKCALCULATIONSREPORT = "BookCalculations";
        public const string MEMBERCALCULATIONSREPORT = "MemberCalculations";

        /// <summary>
        /// The name of the file that stores all the data that will be displayed in the FormsBasedUI unless the test data is loaded
        /// </summary>
        public const string LIBRARY = "library.dat";

    }
}
