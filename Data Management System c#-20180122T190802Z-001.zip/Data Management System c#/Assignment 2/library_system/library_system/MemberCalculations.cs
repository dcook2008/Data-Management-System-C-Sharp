﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library_system
{
    [Serializable]
    public class MemberCalculations
    {
        /// <summary>
        /// A class used to get the data for the BookCalculationsReport class allowing the attributes within it to be controlled elsewhere
        /// </summary>
        private readonly MemberCalculationsReport monthlyMemberReport;
        private readonly MemberList memberList;

        public MemberCalculations(MemberCalculationsReport monthlyMemberReport, MemberList memberList)
        {
            this.monthlyMemberReport = monthlyMemberReport;
            this.memberList = memberList;
        }

        public void DoCalculations()
        {
            // Do the monthly calculations to show important system data on members 
            monthlyMemberReport.TotalMembers = memberList.MembersAmount();
            monthlyMemberReport.AverageMoneyOwed = memberList.AvgMoneyOwed();
            monthlyMemberReport.TotalMoneyOwed = memberList.MembersMoney();

            
        }
    }
}
