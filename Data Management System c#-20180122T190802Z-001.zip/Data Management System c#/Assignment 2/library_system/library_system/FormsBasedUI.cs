﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace library_system
{
    public partial class FormsBasedUI : Form, IUserInterface
    {
        /// <summary>
        /// Classes to be used within the application
        /// </summary>
        MemberList memberList;
        BookList bookList;
        Borrow borrow;
        BookCalculationsReport bookCalReport;
        BookCalculations bookCalculations;
        MemberCalculationsReport memberCalReport;
        MemberCalculations memberCalculations;
        TextReportGenerator textReportGenerator;

        SerializeFileHandler serializeFileHandler;

#region ############### Setup #################

        /// <summary>
        /// Construtor for FormsBasedUI
        /// </summary>
        /// <param name="stu">memberList object</param>
        /// <param name="mod">BookList object</param>
        /// <param name="trg">text report generator object</param>
        public FormsBasedUI(MemberList ml, BookList bl, TextReportGenerator trg, SerializeFileHandler sfh, BookCalculationsReport mbr, BookCalculations bc,
                            MemberCalculationsReport mmr, MemberCalculations mc, Borrow b)
        {
            InitializeComponent();
            borrow = b;
            memberList = ml;
            bookList = bl;
            bookCalReport = mbr;
            bookCalculations = bc;
            memberCalReport = mmr;
            memberCalculations = mc;
            textReportGenerator = trg;
            serializeFileHandler = sfh;
        }

        /// <summary>
        /// Initialisation - load data from external file
        /// or generate test data
        /// </summary>
        private void FormsBasedUI_Load(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to load data from file?",
                          "Load data", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                LoadLibraryData();
            }
            else
            {
                GenerateTestData();
            }
        }

        /// <summary>
        /// Code which can be used to generate data for library_system if the 
        /// data file becomes lost or corrupted
        /// </summary>
        public void GenerateTestData()
        {
            // Instantiate Member objects
            Member m1 = new Member("33A","Daniel Cook");
            Member m2 = new Member("32C", "Robert Paulsen");
            Member m3 = new Member("23F", "Roberta Peterson");
            Member m4 = new Member("13G", "Lucy Barnes");

            memberList.AddMember(m1);
            memberList.AddMember(m2);
            memberList.AddMember(m3);
            memberList.AddMember(m4);

            // Instantiate Book objects 
            Book b1 = new Book("123BR","War and Peace", "LEO TOLSTOY", "WORDSWORTH CLASSICS", 32, 2);
            Book b2 = new Book("223AS", "Anna Karina", "LEO TOLSTOY", "WORDSWORTH CLASSICS", 32, 7);
            Book b3 = new Book("423VE", "The Cossacks and Other Stories", "LEO TOLSTOY", "PENGUIN CLASSICS", 32, 2);
            Book b4 = new Book("522OP", "Resurrection", "LEO TOLSTOY", "PENGUIN CLASSICS", 32, 12);
            Book b5 = new Book("333JK", "Master and Man and Other Stories", "LEO TOLSTOY", "PENGUIN CLASSICS", 32, 22);
            Book b6 = new Book("190LJ", "CHILDHOOD, BOYHOOD, YOUTH", "LEO TOLSTOY", "ONEWORLD CLASSICS", 32, 5);
            Book b7 = new Book("333JK", "The Cossacks and Other Stories", "LEO TOLSTOY", "PENGUIN CLASSICS", 32, 6);

            bookList.AddBook(b1);
            bookList.AddBook(b2);
            bookList.AddBook(b3);
            bookList.AddBook(b4);
            bookList.AddBook(b5);
            bookList.AddBook(b6);
            bookList.AddBook(b7);

            // Instantiate Borrow objects
            Borrow bw1 = new Borrow(b1, m1);
            Borrow bw2 = new Borrow(b3, m3, 34);
            Borrow bw3 = new Borrow(b5, m3, 2);
            Borrow bw4 = new Borrow(b7, m4, 45);


        }

        


        

#endregion

#region ############## Form Code ##############

        private void btnDisplayAllMembers_Click(object sender, EventArgs e)
        {
            DisplayAll(memberList);
        }

        private void btnDisplayAllBooks_Click(object sender, EventArgs e)
        {
            DisplayAll(bookList);
        }

        private void btnAddMember_Click(object sender, EventArgs e)
        {
            AddMember();
        }

        private void btnAddBook_Click(object sender, EventArgs e)
        {
            AddBook();
        }

        private void btnBorrow_Click(object sender, EventArgs e)
        {
            int selectedIndexMember = lstMembers.SelectedIndex;
            int selectedIndexBook = lstBooks.SelectedIndex;

            if (lstMembers.SelectedIndex == -1 || lstBooks.SelectedIndex == -1)
            {
                MessageBox.Show("You must first select the member and a book to borrow");
                DisplayAll(bookList);
                DisplayAll(memberList);
            }
            else
            {
                BorrowBook();
                DisplayAll(bookList);
                DisplayAll(memberList);
                lstMembers.SelectedIndex = selectedIndexMember;
                lstBooks.SelectedIndex = selectedIndexBook;
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            if (lstMembers.SelectedIndex == -1 || lstBooks.SelectedIndex == -1)
            {
                MessageBox.Show("You must first select the member and a book to return");
                DisplayAll(bookList);
                DisplayAll(memberList);
            }
            else
            {
                ReturnBook();
            }
        }

        private void memberToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            IDisplay iDisp = (Member)lstMembers.SelectedItem;
            GenerateTextReport(iDisp);
        }

        private void bookToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            IDisplay iDisp = (Book)lstBooks.SelectedItem;
            GenerateTextReport(iDisp);
        }

        private void allMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GenerateTextReport(memberList);
        }

        private void allBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GenerateTextReport(bookList);
        }

        private void bookReportToolStripMenuItem_Click(object sender, EventArgs e)
        {

            bookCalculations.DoCalculations();
            GenerateTextReport(bookCalReport);
        }

        private void memberReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            memberCalculations.DoCalculations();
            GenerateTextReport(memberCalReport);
        }

        private void lstMembers_SelectedIndexChanged(object sender, EventArgs e)
        {
            IDisplay member = GetItem("M");
            DisplayAll(member);
        }

        private void lstBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            IDisplay book = GetItem("B");
            DisplayAll(book);
        }

        private void btnChangeStock_Click(object sender, EventArgs e)
        {
            if (lstBooks.SelectedIndex == -1)
            {
                MessageBox.Show("You must first select a book to change a book's stock level");
                DisplayAll(bookList);
                
            }
            else
            {
                Book b = (Book)lstBooks.SelectedItem;
                ChangeStock(b);
            }
        }

        private void btnFee_Click(object sender, EventArgs e)
        {
            if(lstMembers.SelectedIndex == -1)
            {
                MessageBox.Show("You must first select a member from the member list to pay a fee");
                DisplayAll(memberList);
            }
            else
            {
                Member m = (Member)lstMembers.SelectedItem;
                PayFee(m);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to save the data file?",
                            "Save data", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                SaveLibraryData();
            }
            Application.Exit();
        }

#endregion

#region ############# IUserInterface #############

        public IDisplay GetItem(string lType)
        {
            if (lType == "M")
            {
                return (Member)lstMembers.SelectedItem;

            }
            else
            {
                return (Book)lstBooks.SelectedItem;
            }
        }

        /// <summary>
        /// Used to gather individual objects from each list then convert to string form using IDisplay then outputing in the forms list
        /// </summary>
        public void DisplayAll(IDisplay obj)
        {
            if (obj is MemberList == true)
            {
                lstMembers.Items.Clear();
                foreach (Member m in memberList.Members)
                {
                    lstMembers.Items.Add(m);
                }
            }
            else if (obj is BookList == true)
            {
                lstBooks.Items.Clear();
                foreach (Book b in bookList.Books)
                {
                    lstBooks.Items.Add(b);
                }
            }
            else
            {
                txtDisplay.Clear();
                txtDisplay.Text = obj.Display();
            }
        }

        /// <summary>
        /// A form is opened where the user can insert the new book information if the data is valid
        /// then the book is added to the system and redisplayed to the user else the user receives a 
        /// message informing the user the book could not be add since the code has been used
        /// </summary>
        public void AddMember()
        {
            AddLibraryData addForm = new AddLibraryData("member");
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                Member newMember = addForm.GetMemberData();

                bool success = memberList.AddMember(newMember);
                if (success)
                {
                    MessageBox.Show(newMember.Code + " has been added to the list");

                    DisplayAll(memberList);

                    txtDisplay.Clear();
                    txtDisplay.Text = newMember.Display();
                }
                else
                {
                    MessageBox.Show("\nUnable to add. This member code has already been used");
                }
            }
        }

        /// <summary>
        /// A form is opened where the user can insert the new member information if the data is valid
        /// then the member is added to the system and redisplayed to the user else the user receives a 
        /// message informing the user the member could not be add since the code has been used
        /// </summary>
        public void AddBook()
        {
            AddLibraryData addForm = new AddLibraryData("book");
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                Book newBook = addForm.GetBookData();

                bool success = bookList.AddBook(newBook);
                if (success)
                {
                    MessageBox.Show(newBook.BookCode + " has been added to the list");

                    DisplayAll(bookList);

                    txtDisplay.Clear();
                    txtDisplay.Text = newBook.Display();
                }
                else
                {
                    MessageBox.Show("\nUnable to add. This member code has already been used");
                }
            }
        }

        /// <summary>
        /// Opens up a form allowing the user to change the stock level of a book dependent on their input
        /// </summary>
        public void ChangeStock(Book b) 
        {
            AddLibraryData addForm = new AddLibraryData(b);
            if(addForm.ShowDialog() == DialogResult.OK)
            {
                addForm.AlterBookStock(b);
            }

        }

        /// <summary>
        /// If a book and member has been selected then a borrow will be created unless the book is already the member or the
        /// book is currently not in the library in this case exceptions will be thrown
        /// </summary>
        public void BorrowBook()
        {

            try
            {
                Book book = (Book)lstBooks.SelectedItem;
                Member member = (Member)lstMembers.SelectedItem;
                Borrow newBorrow = new Borrow(book, member);
            }

            catch (AlreadyBorrowed ab)
            {
                MessageBox.Show(ab.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            catch (OutOfStock os)
            {
                MessageBox.Show(os.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        /// <summary>
        /// Takes a member and book object from the form list and if the user has borrowed the selected book it then return
        /// else a not borrowed exception will be thrown
        /// </summary>
        public void ReturnBook()
        {
            Book book = (Book)lstBooks.SelectedItem;
            Member member = (Member)lstMembers.SelectedItem;

            borrow.ReturnBook(book, member);
        }

        /// <summary>
        /// A method used to generate a report on library objects and informtion the report 
        /// generated is dependent of the IDisplay object type
        /// </summary>
        public void GenerateTextReport(IDisplay obj)
        {
            string filename = "";

            if (obj == null)
            {
                MessageBox.Show("First select the item to be sent to the report file", "No item selected");
            }
            else
            {
                if (obj is Member)
                {
                    Member m = (Member)obj;
                    filename = m.Code;
                }
                else if (obj is Book)
                {
                    Book b = (Book)obj;
                    filename = b.BookCode;
                }
                else if (obj is MemberList)
                {
                    filename = LibraryData.MEMBERS;
                }
                else if(obj is BookCalculationsReport)
                {
                    filename = LibraryData.BOOKCALCULATIONSREPORT;
                }
                else if (obj is MemberCalculationsReport)
                {
                    filename = LibraryData.MEMBERCALCULATIONSREPORT;
                }
                else
                {
                    filename = LibraryData.BOOKS;
                }
                textReportGenerator.GenerateReport(obj, filename + ".txt");
                MessageBox.Show("Text report " + filename + ".txt" + " created.");
            }
        }

        /// <summary>
        /// Creates a library object retrieves the data and saves it by using the serializeFileHandler class
        /// </summary>
        public void SaveLibraryData()
        {
            Library libraryFile = new Library();

            libraryFile.memberList = memberList;
            libraryFile.bookList = bookList;

            serializeFileHandler.SaveLibraryFile(libraryFile, LibraryData.LIBRARY);

            MessageBox.Show("LIBRARY data file has been saved");
        }

        /// <summary>
        /// Checks if there is a library.dat file in exsistence if so an object is create to hold the Library data
        /// the data within the file is then deserialized then copied back into the newly created library object
        /// the library and member lists then also retrive their information from the file
        /// </summary>
        public void LoadLibraryData()
        {
            // Make sure the file library.dat has been created and exists 
            // in the bin\debug folder of this project.
            try
            {
                Library libraryFile = new Library();

                libraryFile = serializeFileHandler.LoadLibraryFile(LibraryData.LIBRARY);

                memberList = libraryFile.memberList;
                bookList = libraryFile.bookList;
                MessageBox.Show("Library data file has been loaded");

            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }

        /// <summary>
        /// Takes the member debt and resets it to 0
        /// </summary>
        public void PayFee(Member member)
        {
            member.PayDebt();
            DisplayAll(memberList);
        }



        #endregion

        

        

        

        

        

        

        





















    }
}