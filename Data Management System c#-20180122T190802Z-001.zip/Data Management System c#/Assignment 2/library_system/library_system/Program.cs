﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace library_system
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

           MemberList memberList = new MemberList();

           BookList bookList = new BookList();

           TextReportGenerator tReportGen = new TextReportGenerator();

           SerializeFileHandler sFileHandler = new SerializeFileHandler();

            BookCalculationsReport mBookReport = new BookCalculationsReport();

            BookCalculations bCalculations = new BookCalculations(mBookReport, bookList);

            MemberCalculationsReport mMemberReport = new MemberCalculationsReport();

            MemberCalculations mCalculations = new MemberCalculations(mMemberReport, memberList);

            Borrow borrow = new Borrow();

            Application.Run(new FormsBasedUI(memberList, bookList, tReportGen,sFileHandler, mBookReport, bCalculations, mMemberReport, mCalculations, borrow));

        }
    }
}
