﻿using System;
using System.Text;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using library_system;


using TestedClass = library_system.BookList;

namespace FileReadnWrite
{
    [TestClass]
    public class SerialableTests
    {
        #region Boilerplate code for the test fixture

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #endregion

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        // Here is where our test case code begins.

        // Common reference to the Factorial class under test, however a new instance of
        // this class will be created for each test case
        private TestedClass testedClass;

        #region Setup and Teardown methods

        [TestInitialize]
        public void TestInitialize()
        {
            // A new instance of the tested class is created for every test case.
            // This is therefore part of each test cases "Arrange" section.
            testedClass = new TestedClass();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            // Ensure that the tested class object reference is set to null so any actual instance can
            // be garbage collected.
            testedClass = null;
        }

        #endregion

        #region isSeriablizeable Tests

        [TestMethod]
        public void BookListIsSerializeableTest()
        {
            
            Type bl = testedClass.GetType();

            var failMessage = bl + " is not serializeable.";

            
            Assert.IsTrue(bl.IsSerializable, failMessage);
        }

        [TestMethod]
        public void BookIsSerializeableTest()
        {
            Book b = new library_system.Book("123BR","Example Title", "LEO TOLSTOY", "WORDSWORTH CLASSICS", 32, 2);

            Type book = testedClass.GetType();

            var failMessage = book + " is not serializeable.";


            Assert.IsTrue(book.IsSerializable, failMessage);
        }

        [TestMethod]
        public void MemberListIsSerializeableTest()
        {
            
            MemberList ml = new library_system.MemberList();

            Type memberl = ml.GetType();

            var failMessage = ml + " is not serializeable.";

            Assert.IsTrue(memberl.IsSerializable, failMessage);
        }

        [TestMethod]
        public void MemberIsSerializeableTest()
        {

            Member ml = new library_system.Member("12A", "John Doe");

            Type memberl = ml.GetType();

            var failMessage = ml + " is not serializeable.";

            Assert.IsTrue(memberl.IsSerializable, failMessage);
        }

        #endregion

    }
}
