﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using library_system;

using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;


// See how the actual class name is aliased to be more general.
// Remember we always only test one class in a fixture so being
// general in this way ensures we do not try to test more than
// one class.
using TestedClass = library_system.SerializeFileHandler;


namespace FileReadnWrite
{
    [TestClass]
    public class SerializeLoadnSaveTests
    {
        #region Boilerplate code for the test fixture

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #endregion

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        // Here is where our test case code begins.

        // Common reference to the Factorial class under test, however a new instance of
        // this class will be created for each test case
        private TestedClass testedClass;

        private const string filename = "library.dat";
        private const string exampleFile = "example.dat";

        #region Setup and Teardown methods

        [TestInitialize]
        public void TestInitialize()
        {
            // A new instance of the tested class is created for every test case.
            // This is therefore part of each test cases "Arrange" section.
            testedClass = new TestedClass();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            // Ensure that the tested class object reference is set to null so any actual instance can
            // be garbage collected.
            testedClass = null;
        }

        #endregion

        #region Save and Load Tests

        [TestMethod]
        public void LoadLibraryObject()
        {
            
            var test = testedClass.LoadLibraryFile(filename);

            var expectedResult = new Library();

            var failMessage = String.Format("Failed to successfully load the file: " + filename);

            Assert.ReferenceEquals(test, expectedResult);

        }

     
        [TestMethod]
        public void SaveLibraryObject()
        {
            var exampleLib = new Library();

            testedClass.SaveLibraryFile(exampleLib, exampleFile);

            var failMessage = String.Format("Failed to save file: " + exampleFile);

            Assert.IsTrue(File.Exists(exampleFile), failMessage);

            // Allows the test to be run over and over knowing the result won't be falsely true as a result of previous unit tests
            if (File.Exists(exampleFile))
            {
                File.Delete(exampleFile);
            }
        }

        #endregion

        

    }
}